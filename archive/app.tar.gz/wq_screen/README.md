# WQScreen Tool
An R script to screen water quality samples using criteria based on their location. Currently criteria is limited to metals in Colorado, Utah, and New Mexico, including state and tribal boundaries. 

